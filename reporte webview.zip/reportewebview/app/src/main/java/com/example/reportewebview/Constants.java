package com.example.reportewebview;

public class Constants {
    public static String MONEDAY = "https://wwws.reddit.com";

}
